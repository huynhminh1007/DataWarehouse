USE db_staging;

DROP TEMPORARY TABLE IF EXISTS temp_products;
-- Tạo bảng tạm đại diện cho dữ liệu từ File
-- Comment các dòng chưa dùng đến
CREATE TEMPORARY TABLE temp_products (
    id INT,
    sku VARCHAR(255),
    product_name VARCHAR(255),
    -- short_description TEXT,
    price DECIMAL(10, 2),
    -- list_price DECIMAL(10, 2),
    -- original_price DECIMAL(10, 2),
    -- discount DECIMAL(10, 2),
    -- discount_rate DECIMAL(5, 2),
    -- all_time_quantity_sold INT,
    -- rating_average DECIMAL(3, 2),
    -- review_count INT,
    -- inventory_status VARCHAR(50),
    -- stock_item_qty INT,
    -- stock_item_max_sale_qty INT,
    brand_id INT,
    brand_name VARCHAR(255),
    -- url_key VARCHAR(255),
    -- url_path VARCHAR(255),
    thumbnail_url VARCHAR(255),
    -- options JSON,
    specifications TEXT -- Hiện đang bị lỗi do JSON bị lỗi do file dấu ' thay vì ". Fix bằng cách sửa file hoặc chuyển cột này sang text hoặc kêu đấng cứu thế ChatGPT =)
    -- variations JSON
);

LOAD DATA INFILE '/var/lib/mysql-files/crawled_data_laptop.csv'
INTO TABLE temp_products
FIELDS TERMINATED BY ',' 
OPTIONALLY ENCLOSED BY '"' 
LINES TERMINATED BY '\n' 
IGNORE 1 ROWS
(id, sku, product_name, @dummy, price, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, @dummy, 
brand_id, brand_name, @dummy, @dummy, thumbnail_url, @dummy, specifications, @dummy);

SELECT COUNT(*) FROM temp_products;

-- TRUNCATE TABLE dim_products;