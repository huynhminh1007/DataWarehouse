USE db_staging;

delimiter //
CREATE PROCEDURE LoadDataFromStagingToDW()
BEGIN
	START TRANSACTION;

    -- Thêm dữ liệu dim_dates từ staging vào dw
    INSERT INTO db_datawarehouse.dim_dates (
		date_sk,               -- Khóa chính, sử dụng cho định danh ngày
		full_date,                        -- Ngày đầy đủ
		day_since_2005,                    -- Số ngày kể từ năm 2005
		month_since_2005,                  -- Số tháng kể từ năm 2005
		day_of_week,                -- Tên ngày trong tuần
		calendar_month,             -- Tên tháng
		calendar_year,                     -- Năm lịch
		calendar_year_month,       -- Định dạng YYYY-MMM
		day_of_month,                      -- Ngày trong tháng
		day_of_year,                       -- Ngày trong năm
		week_of_year_sunday,               -- Tuần của năm theo Chủ nhật
		year_week_sunday,	-- Định dạng YYYY-Www
		week_sunday_start,                -- Ngày bắt đầu tuần theo Chủ nhật
		week_of_year_monday,               -- Tuần của năm theo Thứ hai
		year_week_monday,          -- Định dạng YYYY-Www
		week_monday_start,                -- Ngày bắt đầu tuần theo Thứ hai
		quarter_of_year,                   -- Quý của năm
		quarter_since_2005 ,                -- Quý kể từ năm 2005
		holiday,                   -- Trạng thái ngày lễ
		date_type                  -- Kiểu ngày (Weekend/Weekday)
	)
	SELECT 
		date_sk,               -- Khóa chính, sử dụng cho định danh ngày
		full_date,                        -- Ngày đầy đủ
		day_since_2005,                    -- Số ngày kể từ năm 2005
		month_since_2005,                  -- Số tháng kể từ năm 2005
		day_of_week,                -- Tên ngày trong tuần
		calendar_month,             -- Tên tháng
		calendar_year,                     -- Năm lịch
		calendar_year_month,       -- Định dạng YYYY-MMM
		day_of_month,                      -- Ngày trong tháng
		day_of_year,                       -- Ngày trong năm
		week_of_year_sunday,               -- Tuần của năm theo Chủ nhật
		year_week_sunday,	-- Định dạng YYYY-Www
		week_sunday_start,                -- Ngày bắt đầu tuần theo Chủ nhật
		week_of_year_monday,               -- Tuần của năm theo Thứ hai
		year_week_monday,          -- Định dạng YYYY-Www
		week_monday_start,                -- Ngày bắt đầu tuần theo Thứ hai
		quarter_of_year,                   -- Quý của năm
		quarter_since_2005 ,                -- Quý kể từ năm 2005
		holiday,                   -- Trạng thái ngày lễ
		date_type                  -- Kiểu ngày (Weekend/Weekday)
	FROM db_staging.dim_dates as ds
    WHERE NOT EXISTS (
    SELECT 1 
    FROM db_datawarehouse.dim_dates AS dw
    WHERE dw.date_sk = ds.date_sk
	);
    
    DELETE FROM db_staging.dim_products 
    WHERE product_name LIKE 'None';
    
    -- Tạo bảng date tạm dựa vào các log đã sẵn sàng chuyển staging vào dw
    CREATE TEMPORARY TABLE temp_dates AS 
    SELECT DISTINCT dd.date_sk
    FROM db_controls.staging_logs AS l
    JOIN db_staging.dim_dates AS dd ON l.last_updated = dd.full_date
    WHERE l.status LIKE 'RE';
    
    -- Tạo bảng tạm cho sản phẩm từ staging với các giá trị duy nhất và có date mới (dựa vào date tạm)
	CREATE TEMPORARY TABLE temp_staging_products AS
    SELECT *
    FROM (
        SELECT p.*,
               ROW_NUMBER() OVER (
                   PARTITION BY p.sku_no, p.manufacturer, p.original_price, p.price, p.stock_item_qty
                   ORDER BY p.manufacturer
               ) AS row_num
        FROM db_staging.dim_products AS p
        JOIN temp_dates AS td ON p.dim_date = td.date_sk
    ) AS temp
    WHERE row_num = 1;

    -- Thêm các nhà sản xuất vào bảng dim_manufacturers từ bảng tạm
	INSERT IGNORE INTO db_datawarehouse.dim_manufacturers(natural_key, manufacture_name, is_active)
	SELECT DISTINCT tp.manufacturer_id, tp.manufacture_name, 1
	FROM temp_staging_products AS tp
	WHERE tp.manufacture_name NOT LIKE 'NONE'
	AND NOT EXISTS (
		SELECT 1
		FROM db_datawarehouse.dim_manufacturers dm
		WHERE dm.natural_key = tp.manufacturer_id
	);

    -- Tạo bảng tạm cho sản phẩm đã tồn tại trong data warehouse, chỉ lấy các product trong phạm vi date tạm, tránh truy vấn hết cả bảng
	CREATE TEMPORARY TABLE temp_dw_products AS
	SELECT *
	FROM (
		SELECT p.sku_no, p.manufacturer_id, p.product_name, p.product_description, p.image_url, p.specifications, p.in_active, pa.original_price, pa.price, pa.stock,
           ROW_NUMBER() OVER (
               PARTITION BY p.sku_no, p.manufacturer_id, p.product_name, p.product_description, p.image_url, p.specifications, p.in_active, pa.original_price, pa.price, pa.stock
               ORDER BY p.manufacturer
           ) AS row_num
		FROM db_datawarehouse.dim_products AS p
		JOIN temp_dates AS td ON p.dim_date = td.date_sk
		JOIN db_datawarehouse.dim_product_attrs AS pa ON p.sku_no = pa.sku_no 
		) AS temp
	WHERE row_num = 1;

	-- Thêm sản phẩm mới vào bảng dim_products
	INSERT INTO db_datawarehouse.dim_products (natural_key, sku_no, product_name, product_description, image_url, specifications, manufacturer_id, insert_date)
	SELECT tsp.natural_key, tsp.sku_no, tsp.product_name, tsp.product_description, tsp.image_url, tsp.specifications, tsp.manufacturer_id, td.date_sk  -- Sử dụng khóa ngoại từ bảng dim_dates
	FROM temp_staging_products AS tsp
	JOIN temp_dates AS td ON td.date_sk = (SELECT MAX(date_sk) FROM dim_dates WHERE full_date = CURDATE())  -- Chọn khóa ngoại từ dim_dates dựa trên ngày hiện tại
	WHERE NOT EXISTS (
		SELECT 1
		FROM temp_dw_products AS tdwp
		WHERE tdwp.sku_no = tsp.sku_no
	);

    -- Tạo bảng tạm cho các sản phẩm cần cập nhật
	CREATE TEMPORARY TABLE temp_update_products AS
    SELECT tsp.*
    FROM temp_staging_products AS tsp
    WHERE EXISTS (
        SELECT 1
        FROM temp_dw_products AS tdwp
        WHERE tdwp.sku_no = tsp.sku_no
        AND tdwp.in_active = '1'
        AND (tdwp.image_url <> tsp.image_url OR
			tdwp.product_name <> tsp.product_name OR
			tdwp.manufacturer_id <> tsp.manufacturer_id OR
			tdwp.product_description <> tsp.product_description OR
			tdwp.specifications <> tsp.specifications OR
			tdwp.original_price <> tsp.original_price OR
			tdwp.price <> tsp.price)
    );

	-- Cập nhật trạng thái sản phẩm không còn hoạt động
	UPDATE db_datawarehouse.dim_products dp
	SET dp.in_active = '0'
	WHERE EXISTS (
		SELECT 1
		FROM temp_update_products tup
		WHERE tup.product_name = dp.product_name
		AND tup.manufacturer_id = dp.manufacturer_id
	);

	-- Thêm các sản phẩm đã cập nhật vào bảng dim_products
	INSERT INTO db_datawarehouse.dim_products(natural_key, sku_no, product_name, product_description, image_url, specifications, manufacturer_id, insert_date)
	SELECT tup.natural_key, tup.sku_no, tup.product_name, tup.product_description, tup.image_url, tup.specifications, tup.manufacturer_id, td.date_sk  -- Sử dụng khóa ngoại từ bảng dim_dates
	FROM temp_update_products AS tup
	JOIN temp_dates AS td ON td.date_sk = (SELECT MAX(date_sk) FROM dim_dates WHERE full_date = CURDATE());  -- Chọn khóa ngoại từ dim_dates dựa trên ngày hiện tại
	
    COMMIT;
END //
delimiter ;

CALL LoadDataFromStagingToDW();
DROP PROCEDURE db_staging.LoadDataFromStagingToDW;