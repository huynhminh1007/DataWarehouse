CREATE DATABASE IF NOT EXISTS db_datawarehouse;
USE db_datawarehouse;

ALTER DATABASE db_datawarehouse CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Table: dim_dates
CREATE TABLE IF NOT EXISTS dim_dates (
    date_sk INT PRIMARY KEY,
    full_date DATE,
    day_since_2005 INT,
    month_since_2005 INT,
    day_of_week VARCHAR(10),
    calendar_month VARCHAR(15),
    calendar_year INT,
    calendar_year_month VARCHAR(255),
    day_of_month INT,
    day_of_year INT,
    week_of_year_sunday INT,
    year_week_sunday VARCHAR(255),
    week_sunday_start DATE,
    week_of_year_monday INT,
    year_week_monday VARCHAR(255),
    week_monday_start DATE,
    quarter_of_year VARCHAR(255),
    quarter_since_2005 INT,
    holiday VARCHAR(255),
    date_type VARCHAR(15)
);

-- Table: dim_manufacturers
CREATE TABLE IF NOT EXISTS dim_manufacturers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    natural_key INT UNSIGNED NOT NULL,
    manufacturer_name VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    is_active TINYINT(1) UNSIGNED DEFAULT '0' COMMENT '0: inactive, 1: active',
    delete_date INT,
    insert_date INT,
    update_date INT,
    FOREIGN KEY (delete_date) REFERENCES dim_dates(date_sk) ON DELETE SET NULL,
    FOREIGN KEY (insert_date) REFERENCES dim_dates(date_sk) ON DELETE SET NULL,
    FOREIGN KEY (update_date) REFERENCES dim_dates(date_sk) ON DELETE SET NULL
);

-- Table: dim_products
CREATE TABLE IF NOT EXISTS dim_products (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    natural_key INT UNSIGNED NOT NULL,
    sku_no VARCHAR(32) NOT NULL,
    product_name VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
    product_description VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
    image_url VARCHAR(255),
    specifications JSON DEFAULT NULL,
    manufacturer_id INT UNSIGNED,
    is_active TINYINT(1) UNSIGNED DEFAULT '0' COMMENT '0: inactive, 1: active',
    delete_date INT,
    insert_date INT,
    update_date INT,
    UNIQUE KEY uk_sku_no (sku_no) USING BTREE,
    FOREIGN KEY (manufacturer_id) REFERENCES dim_manufacturers(id) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (delete_date) REFERENCES dim_dates(date_sk) ON DELETE SET NULL,
    FOREIGN KEY (insert_date) REFERENCES dim_dates(date_sk) ON DELETE SET NULL,
    FOREIGN KEY (update_date) REFERENCES dim_dates(date_sk) ON DELETE SET NULL
) COMMENT = 'SKU';

-- Table: dim_product_attrs
CREATE TABLE IF NOT EXISTS dim_product_attrs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sku_no VARCHAR(32) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    original_price DECIMAL(10, 2) NOT NULL,
    stock INT UNSIGNED DEFAULT '0',
    is_active TINYINT(1) UNSIGNED DEFAULT '0' COMMENT '0: inactive, 1: active',
    delete_date INT,
    insert_date INT,
    update_date INT,
    expired_date DATE DEFAULT '9999-12-31',
    FOREIGN KEY (sku_no) REFERENCES dim_products(sku_no) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (delete_date) REFERENCES dim_dates(date_sk) ON DELETE SET NULL,
    FOREIGN KEY (insert_date) REFERENCES dim_dates(date_sk) ON DELETE SET NULL,
    FOREIGN KEY (update_date) REFERENCES dim_dates(date_sk) ON DELETE SET NULL
);