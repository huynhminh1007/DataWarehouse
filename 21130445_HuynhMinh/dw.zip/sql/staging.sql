CREATE DATABASE IF NOT EXISTS db_staging;
USE db_staging;

ALTER DATABASE db_staging CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Table: dim_dates
CREATE TABLE IF NOT EXISTS dim_dates (
    date_sk INT PRIMARY KEY,
    full_date DATE,
    day_since_2005 INT,
    month_since_2005 INT,
    day_of_week VARCHAR(10),
    calendar_month VARCHAR(15),
    calendar_year INT,
    calendar_year_month VARCHAR(255),
    day_of_month INT,
    day_of_year INT,
    week_of_year_sunday INT,
    year_week_sunday VARCHAR(255),
    week_sunday_start DATE,
    week_of_year_monday INT,
    year_week_monday VARCHAR(255),
    week_monday_start DATE,
    quarter_of_year VARCHAR(255),
    quarter_since_2005 INT,
    holiday VARCHAR(255),
    date_type VARCHAR(15)
);

CREATE TABLE IF NOT EXISTS dim_tiki_products (
    natural_key TEXT,
    sku TEXT,
    product_name TEXT,
    short_description TEXT,
    price TEXT,
    list_price TEXT,
    original_price TEXT,
    discount TEXT,
    discount_rate TEXT,
    all_time_quantity_sold TEXT,
    rating_average TEXT,
    review_count TEXT,
    inventory_status TEXT,
    stock_item_qty TEXT,
    stock_item_max_sale_qty TEXT,
    brand_id TEXT,
    brand_name TEXT,
    url_key TEXT,
    url_path TEXT,
    thumbnail_url TEXT,
    options TEXT,
    specifications TEXT,
    variations TEXT
);