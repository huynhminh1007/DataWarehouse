package com.example.datawarehouseserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataWarehouseServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
