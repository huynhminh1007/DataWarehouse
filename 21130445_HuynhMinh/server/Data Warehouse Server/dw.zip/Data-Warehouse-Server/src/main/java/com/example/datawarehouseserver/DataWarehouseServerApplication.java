package com.example.datawarehouseserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataWarehouseServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataWarehouseServerApplication.class, args);
	}

}
